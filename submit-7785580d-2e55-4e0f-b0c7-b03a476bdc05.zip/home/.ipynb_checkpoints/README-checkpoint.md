### Data Warehouse

The objective of this project is to build database warehouse in Amazon cloud environment by building ETL pipeline that extracts data from Amazon S3 in order to achieve analytics goals.

#### Motivation

As the music streaming startup, Sparkify, has grown, their volume of data has grown as well. The motivation behind this project is to build a ETL pipeline that extracts data from S3, stages them in Redshift, and transform data into a set of dimensional tables for their analytics team to continue finding insights in what songs their users are listening. Having the Data Warehouse in cloud would help Sparkify in better decision making, consolidate data from many log files and event files to one single database and also providing them with robust peroformance and analytic capabilities. 

#### Process involved
1. First of all I created Amazaon Redshift Cluster and made sure user/roles were created in order to connect to cluster.
2. Data Discovery/Investigation: Song and log data were in Amazon S3.\
   To investigate the data layout I refered to project datasets page. Based on this data I wrote query to create staging table
2. Create Database and Associated tables: Sparkify database was created and tables- staging_events,staging_songs, users, songs, artists,\
   songplays and time were created. Staging table were created to bring the Song and log data files. Based on the data on these files other tables were\
   created to build the Database Warehouse following proper Data warehouse architecture.
3. Create Star Schema: Since the main purpose behind creation of Sparkify database warehouse was to provide quick and easy\
   way to query the data, **songplays** fact table was created.  The songplays table records log data accociated\
   with song plays. Fact table will provide the startup with quantitative information for analysis.
4. Create Data Pipeline: In order to create the data pipeline from JSON file stored in S3 to the data warehouse an ETL\
   process was created using python to load data from json files to first to stagging table and after to the associated\
   tables.
5. Test: Test was conducted to make sure the ETL process was loading data to correct tables. To perform the test\
   below steps were taken
               a. Run ***create_tables.py*** in python3 console using **% run create_tables.py** - this calls\
                  **sql_queries.py** and creates database and tables
               b. Run ***etl.py*** in python3 console using **% run etl.py** - this file contains all the process\
                  involved required to load data from json to associated tables in ***sparkify*** database warehouse.

#### Data Warehouse Star Schema Design and Python for ETL
Sparkify Data Warehouse  was created to asist the start up to easily query their data in cloud environment for data analytics. Sparkify data warehouse was structured as a relational and normalized database following the data warehouse architecture. Data was staged to staging table to check for duplicates, make sure data were in correct format and for loading to specific dimensions and fact tables.The dimension tables users, songs, artists, and time were created to store specific data belonging
to those tables. For example users table contains all the users data like their userid, fistname, lastname, gender and level. Having database in normalized form have reduced reduncancy of data and data dependencies are logical. 

Fact table songplays was created and it acts as the central table in star schema. **Songplays** table references the dimension tables song_id , artist_id, user_id and start_time.The star schema will provide the start up with easy access to the users data. They can easily query the fact table **songplays** to get quantitative informations like the how many times did the user played the same song, how many times was the songs played in certain locations, how long were the users active in the app etc... This design should help startup querying the user data much easier and faster since it contains most of the user information.

ETL pipeline was built using Python. Data was transfered from json files residing in amazon s3 to tables in **sparkify** using **Python and SQL**. Python was a good choice to for creating the ETL solution becuase of felxibility and good libraries like pandas and numpy that assist in data migration, data wrangling and felxible choices to connect different datasources. While building ETL project there are several things that should be considered like **schema changes**, **data visibility** and **scalability**. From my stand point I think creating ETL in Python has advantages over all these areas. This ETL process can easily be adjusted if there is any schema changes with in sparkify database, it also provides full control, instead of reliying on third party tool which might not support the new requirements. Also, as business grows the startup might need to create few other dimensions tables and start logging other informations. This ETL process gives felxibility to startup to scale ETL process by allowing them to modify to add more dimension tables, make changes to fact tables, get files from different sources etc.

As Sparkify data has grown and since data need to be readily available, secure and scalable, having dataware house built in Amazon Redshift provides all these advantages of reliability, performance and scalability. Data warehouse would provide below benefits to Sparkify analytics team
1. Better decision making
2. Consolidates data from event logs and songs data and in future other sources can also be added
3. Helps maintain data quality, consistency and accuracy 
4. Provides analytics historical trends and intellegence in each and every user song preferences, songs played stats in different time and locations etc.
5. Data warehosue would provide a analytic teams an environment for data visualization and all other analytical needs

#### Queries for Quantitavive Analysis

1. Get times a song was played by a user
`Select song_id,user_id, count(*) as total from songplays where song_id<>'None' group by song_id, user_id`
2. Get times a song was played based on location
`select song_id, location, count(*) as total from songplays where song_id<>'None' group by song_id, location`
3. Get most played artist
`select s.artist_id,a.name as artist_name, count(*) as total from songplays s join artists a on s.artist_id = a.artist_id group by s.artist_id,a.name`
4. Get users who have level ='paid' with their information
`select distinct s.user_ID,u.first_name,u.last_name,u.gender from songplays s join users u on s.user_id = u.user_id where s.level='paid'`



#### References
1. Udacity tutorials
2. https://aws.amazon.com/data-warehouse/
3. https://datascience.stackexchange.com
4. https://docs.aws.amazon.com/redshift/index.html














