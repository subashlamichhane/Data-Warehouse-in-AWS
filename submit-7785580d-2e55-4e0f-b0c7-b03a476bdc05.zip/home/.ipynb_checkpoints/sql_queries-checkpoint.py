import configparser


# CONFIG
config = configparser.ConfigParser()
config.read('dwh.cfg')

# DROP TABLES

staging_events_table_drop = "drop table if exists staging_events"
staging_songs_table_drop = "drop table if exists staging_songs"
songplay_table_drop = "drop table if exists songplays"
user_table_drop = "drop table if exists users"
song_table_drop = "drop table if exists songs"
artist_table_drop = "drop table if exists artists"
time_table_drop = "drop table if exists time"

# CREATE TABLES

staging_events_table_create= ("""create table staging_events(ID bigint Identity(0,1) not null,\
                                artist varchar,auth varchar,firstName varchar ,gender char,\
                                iteminSession int ,lastName varchar,length decimal,level varchar,
                                location varchar,method varchar,page varchar,registration decimal,
                                sessionId int,song varchar,status int,ts bigint,userAgent varchar,\
                                userID int)
                                """)

staging_songs_table_create = ("""create table staging_songs(num_songs bigint,artist_id varchar,\
                                artist_latitude float,artist_longitude float,artist_location varchar,\
                                artist_name varchar,song_id varchar,title varchar,duration double precision,year int)
                                """)

songplay_table_create = ("""create table songplays(songplay_id int Primary Key identity(0,1) not null,start_time timestamp,\
                            user_id int,level varchar,song_id varchar,artist_id varchar,session_id int,location varchar,user_agent varchar)
                            """)

user_table_create = ("""create table users(user_id int Primary Key not null ,first_name varchar,last_name varchar,gender char,level varchar)
""")

song_table_create = ("""create table songs(song_id varchar Primary Key not null ,title varchar,artist_id varchar,year int,duration double precision)
""")

artist_table_create = ("""create table artists(artist_id varchar Primary Key  not null,name varchar,location varchar,latitude float,longitude float)
""")

time_table_create = ("""Create table time(start_time timestamp NOT NULL Primary Key,hour int,day int,week int,month varchar,year int,weekday varchar)
""")

# STAGING TABLES

staging_events_copy = ("""COPY staging_events FROM {}\
                               iam_role{}\
                               region 'us-west-2'\
                               FORMAT as JSON{};
""").format(config.get("S3","LOG_DATA"),config.get("IAM_ROLE","ARN"),config.get("S3","LOG_JSONPATH"))

staging_songs_copy = ("""COPY staging_songs FROM {}
                        iam_role{}\
                        region 'us-west-2'\
                        FORMAT AS JSON 'auto';
""").format(config.get("S3","SONG_DATA"), config.get("IAM_ROLE","ARN"))


# FINAL TABLES

songplay_table_insert = ("""INSERT INTO songplays \
(start_time, user_id, level, song_id, artist_id, session_id, location, user_agent) \
SELECT DISTINCT \
    TIMESTAMP 'epoch' + ts/1000 *INTERVAL '1 second' as start_time, \
    se.userId, \
    se.level, \
    ss.song_id, \
    ss.artist_id, \
    se.sessionid, \
    se.location, \
    se.useragent \
FROM staging_events se
join staging_songs ss on 
se.song = ss.title
and se.artist = ss.artist_name
where se.page = 'NextSong';
""")

user_table_insert = ("""INSERT INTO users \
(user_id, first_name, last_name, gender, level) \
SELECT DISTINCT \
    userId, \
    firstName, \
    lastName, \
    gender, \
    level \
FROM staging_events
where userid is not null
and userid not in (select userid from users);
""")

song_table_insert = ("""INSERT INTO songs \
(song_id, title, artist_id, year, duration) \
SELECT DISTINCT \
    song_id, \
    title, \
    artist_id, \
    year, \
    duration \
FROM staging_songs
where song_id is not null
and song_id not in (select song_id from songs);
""")

artist_table_insert = ("""INSERT INTO artists \
(artist_id, name, location, latitude, longitude) \
SELECT DISTINCT \
    artist_id, \
    artist_name, \
    artist_location, \
    artist_latitude, \
    artist_longitude \
FROM staging_songs
where artist_id is not null
and artist_id not in (select artist_id from artists);
""")

time_table_insert = (""" Insert into time(start_time,hour,day,week,month,year,weekday)\
Select Distinct start_time,\
Extract(hr from start_time),\
Extract(d from start_time),\
Extract(w from start_time),\
Extract(mon from start_time),\
Extract(yr from start_time),\
Extract(weekday from start_time)
From (select Distinct TimeStamp 'epoch'+ts/1000 *interval '1 second' as start_time \ from Staging_events)s
""")

# QUERY LISTS

create_table_queries = [staging_events_table_create, staging_songs_table_create, songplay_table_create, user_table_create, song_table_create, artist_table_create, time_table_create]
drop_table_queries = [staging_events_table_drop, staging_songs_table_drop, songplay_table_drop, user_table_drop, song_table_drop, artist_table_drop, time_table_drop]
copy_table_queries = [staging_events_copy, staging_songs_copy]
insert_table_queries = [songplay_table_insert, user_table_insert, song_table_insert, artist_table_insert, time_table_insert]
