import configparser
import psycopg2
from sql_queries import create_table_queries, drop_table_queries


def drop_tables(cur, conn):
    """This function has two parameters cur and conn.Cur is used for cursor and conn is used to store connection information.\
    This function executes drop_table_queries- if any tables exists and they are dropped"""
    for query in drop_table_queries:
        cur.execute(query)
        conn.commit()


def create_tables(cur, conn):
    """This function has two parameters cur and conn.Cur is used for cursor and conn is used to store connection information.\
    This function executes create table queries."""
    for query in create_table_queries:
        cur.execute(query)
        conn.commit()


def main():
    """Main function extablishes the cur and conn variables and then executes drop_tables and create_tables functions"""
    config = configparser.ConfigParser()
    config.read('dwh.cfg')
    host = config.get("CLUSTER","HOST")
    dbname= config.get("CLUSTER","DB_NAME")
    user = config.get("CLUSTER", "DB_USER")
    password = config.get("CLUSTER", "DB_PASSWORD")
    port = config.get("CLUSTER", "DB_PORT")

    conn = psycopg2.connect(f"host={host} dbname={dbname} user={user} password={password} port={port}".format(*config['CLUSTER'].values()))
    cur = conn.cursor()

    drop_tables(cur, conn)
    create_tables(cur, conn)

    conn.close()


if __name__ == "__main__":
    main()