import configparser
import psycopg2
from sql_queries import copy_table_queries, insert_table_queries


def load_staging_tables(cur, conn):
    """This function has two parameters cur and conn.Cur is used for cursor and conn is used to store connection information.\
    This function executes the Copy commands to get data from S3 bucket to respective staging table"""
    for query in copy_table_queries:
        cur.execute(query)
        conn.commit()


def insert_tables(cur, conn):
    """This function has two parameters cur and conn.Cur is used for cursor and conn is used to store connection information.\
    This function executes the insert table queries, that loads fact and dimension tables data from staging tables."""
    for query in insert_table_queries:
        cur.execute(query)
        conn.commit()


def main():
    """The main function establishes connection to Amazon Redshift Cluster and then executes load_staging_tables and insert_tables functions."""
    config = configparser.ConfigParser()
    config.read('dwh.cfg')
    host = config.get("CLUSTER","HOST")
    dbname= config.get("CLUSTER","DB_NAME")
    user = config.get("CLUSTER", "DB_USER")
    password = config.get("CLUSTER", "DB_PASSWORD")
    port = config.get("CLUSTER", "DB_PORT")
    conn = psycopg2.connect(f"host={host} dbname={dbname} user={user} password={password} port={port}")
    cur = conn.cursor()
    
    load_staging_tables(cur, conn)
    insert_tables(cur, conn)

    conn.close()


if __name__ == "__main__":
    main()